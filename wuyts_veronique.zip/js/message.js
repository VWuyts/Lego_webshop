/* Lego Webshop
 *
 * Lab assignment for course PHP & MySQL 2017
 * Thomas More campus De Nayer
 * Bachelor Elektronica-ICT -- Application Development
 * 
 * Véronique Wuyts
 *
 * message.js
 */

// redirect users to home page after 10 seconds
window.setTimeout(function(){
    window.location = '../index.php';
},10000);